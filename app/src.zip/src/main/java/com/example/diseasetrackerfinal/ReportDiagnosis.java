package com.example.diseasetrackerfinal;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ReportDiagnosis extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_report_diagnosis);
    }
}