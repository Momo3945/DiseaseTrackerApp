package com.example.diseasetrackerfinal;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ActivityOptions;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Response;

public class SignUpPage extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up_page);


    }

    public void SignUp(View view) {
        NetworkCalls networkCalls = new NetworkCalls();
        String name = ((EditText) findViewById(R.id.Name)).getText().toString();
        String surname = ((EditText) findViewById(R.id.Surname)).getText().toString();
        String ID = ((EditText) findViewById(R.id.identificationNumber)).getText().toString();
        String DoB = ((EditText) findViewById(R.id.Dob)).getText().toString();
        String email = ((EditText) findViewById(R.id.emailEdit)).getText().toString();
        String password = ((EditText) findViewById(R.id.passwordEdit)).getText().toString();
        TextView signup = findViewById(R.id.signText);

        networkCalls.signUp(name,surname,ID,DoB,email, password, new Callback() {
            @Override
            public void onFailure(@NonNull Call call, @NonNull IOException e) {

            }

            @Override
            public void onResponse(@NonNull Call call, @NonNull Response response) throws IOException {
                if (response.isSuccessful()){
                    String responseBody = response.body().string();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if(responseBody.trim().equals("SignUp successful")){
                                Intent intent = new Intent(SignUpPage.this,LoginPage.class);
                                startActivity(intent, ActivityOptions.makeSceneTransitionAnimation(SignUpPage.this).toBundle());
                            }
                            else{
                                signup.setText(responseBody);
                                signup.setBackground(getDrawable(R.drawable.error));
                                signup.setTextSize(18);
                            }




                        }
                    });
                }
                else{
                    String errorMessage = response.message();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            signup.setText(errorMessage);
                            signup.setBackground(getDrawable(R.drawable.error));
                            signup.setTextSize(18);
                        }
                    });


                }

            }
        });


    }
}

